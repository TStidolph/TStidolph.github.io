Any application log files will be written to this directory.
